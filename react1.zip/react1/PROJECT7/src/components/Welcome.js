/*import React, { Component } from 'react'
const Greet = ({name,info}) => {

    render() {
        const {name,info}= this.props
        //const {state1,state2}=this.state
        return (
            <h1>
                Welcome {this.props.name} s.n.e {this.props.info}
            </h1>
        )
    }
}
export default Welcome
*/