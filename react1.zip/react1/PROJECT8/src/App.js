

import React, { Component } from 'react'

import './App.css';

import FunctioncCick from './component/FunctioncCick';
import ClassClick from './component/ClassClick'
class App extends Component {
  render (){

  
  return (
    <div className="App">
     <FunctioncCick ></FunctioncCick>
     <ClassClick></ClassClick>
    </div>
  );
}
}
export default App;
