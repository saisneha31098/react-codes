import React, { Component } from 'react';

import './App.css';
import Greet from './components/Greet'

class App extends Component {
  render(){
  return (
   <div className="App">
     <Greet name="sneha" info="name" />
     <Greet name="cse" info="dept" />
     <Greet name="capg" info="company" />
   </div>
  );
  }
}
 export default App;
