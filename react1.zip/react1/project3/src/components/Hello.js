import  React from 'react'
const Hello = () => {
   // return (
     //   <div>

//<h1>hello sneha</h1>
  //      </div>
    //)
    return React.createElement('div', 
    null,
    React.createElement('h1',null,'hello sneha'))
}
export default Hello